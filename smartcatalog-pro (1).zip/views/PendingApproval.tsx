
import React from 'react';
import { Clock, LogOut, ShieldAlert, MessageSquare } from 'lucide-react';

interface PendingApprovalViewProps {
  onLogout: () => void;
}

const PendingApprovalView: React.FC<PendingApprovalViewProps> = ({ onLogout }) => {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto">
      <div className="relative mb-8">
        <div className="w-24 h-24 bg-amber-100 rounded-full flex items-center justify-center text-amber-600">
          <Clock size={48} className="animate-pulse" />
        </div>
        <div className="absolute -bottom-1 -right-1 bg-white p-1.5 rounded-full shadow-md border border-amber-50">
          <ShieldAlert size={20} className="text-amber-500" />
        </div>
      </div>

      <h2 className="text-2xl font-black text-slate-900 mb-4 tracking-tight">Account Pending Approval</h2>
      
      <p className="text-slate-500 font-medium leading-relaxed mb-8">
        Welcome to SmartCatalog Pro! Your account request has been received. Our administrators are currently reviewing your profile and assigning your specific price list.
      </p>

      <div className="w-full space-y-3">
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex items-center gap-4 text-left">
          <MessageSquare size={24} className="text-blue-500 shrink-0" />
          <div>
            <h4 className="text-sm font-bold text-slate-800">Need immediate help?</h4>
            <p className="text-xs text-slate-400">Contact our support desk to expedite your request.</p>
          </div>
        </div>

        <button 
          onClick={onLogout}
          className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold shadow-lg active:scale-95 transition-all flex items-center justify-center gap-3 mt-6"
        >
          <LogOut size={20} />
          Sign Out & Return Home
        </button>
      </div>

      <p className="mt-12 text-[10px] text-slate-300 font-black uppercase tracking-widest">
        SmartCatalog Administrator System
      </p>
    </div>
  );
};

export default PendingApprovalView;
