
import React from 'react';
import { Minus, Plus, Trash2, ShoppingBag, CreditCard } from 'lucide-react';
import { CartItem } from '../types';

interface CartProps {
  cart: CartItem[];
  onUpdateQuantity: (id: string, packaging: string, delta: number) => void;
  onRemove: (id: string, packaging: string) => void;
  onCheckout: () => void;
}

const CartView: React.FC<CartProps> = ({ cart, onUpdateQuantity, onRemove, onCheckout }) => {
  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = cart.length > 0 ? 12.00 : 0;
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center animate-in fade-in duration-500">
        <div className="bg-slate-100 p-8 rounded-full mb-6">
          <ShoppingBag size={64} className="text-slate-300" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">Your cart is empty</h2>
        <p className="text-slate-400 text-sm mt-2 mb-8">
          Browse our catalog and discover amazing products to fill your cart.
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6 pb-40">
      <h2 className="text-2xl font-bold text-slate-800 mb-4">My Shopping Cart</h2>
      
      <div className="space-y-4">
        {cart.map((item, idx) => (
          <div 
            key={`${item.id}-${item.selectedPackaging}-${idx}`}
            className="flex gap-4 bg-white p-4 rounded-3xl shadow-sm border border-slate-100 animate-in slide-in-from-right-2"
          >
            <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 bg-slate-50">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 flex flex-col justify-between min-w-0">
              <div className="flex justify-between items-start gap-2">
                <div className="min-w-0">
                  <h3 className="font-bold text-slate-800 text-sm truncate">{item.name}</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 uppercase tracking-wide">{item.selectedPackaging}</p>
                </div>
                <button 
                  onClick={() => onRemove(item.id, item.selectedPackaging)}
                  className="text-slate-300 hover:text-red-500 p-1 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
              
              <div className="flex items-center justify-between mt-2">
                <span className="font-black text-slate-900 text-sm">${(item.price * item.quantity).toFixed(2)}</span>
                <div className="flex items-center gap-3 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200">
                  <button 
                    onClick={() => onUpdateQuantity(item.id, item.selectedPackaging, -1)}
                    className="text-slate-400 hover:text-blue-600"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="text-xs font-bold text-slate-800 w-4 text-center">{item.quantity}</span>
                  <button 
                    onClick={() => onUpdateQuantity(item.id, item.selectedPackaging, 1)}
                    className="text-slate-400 hover:text-blue-600"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Checkout Summary */}
      <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-3">
        <div className="flex justify-between text-sm text-slate-500">
          <span>Subtotal</span>
          <span className="font-semibold text-slate-800">${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm text-slate-500">
          <span>Shipping fee</span>
          <span className="font-semibold text-slate-800">${shipping.toFixed(2)}</span>
        </div>
        <div className="h-px bg-slate-100 my-2"></div>
        <div className="flex justify-between text-lg font-bold">
          <span className="text-slate-800">Total Order</span>
          <span className="text-blue-600">${total.toFixed(2)}</span>
        </div>
      </div>

      <div className="fixed bottom-24 left-4 right-4 max-w-md mx-auto">
        <button 
          onClick={onCheckout}
          className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3"
        >
          <CreditCard size={20} />
          Confirm Order
        </button>
      </div>
    </div>
  );
};

export default CartView;
