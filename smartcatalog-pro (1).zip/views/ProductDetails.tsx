
import React, { useState } from 'react';
import { ChevronLeft, Plus, Minus, CheckCircle, Tag } from 'lucide-react';
import { Product, PriceListId } from '../types';

interface ProductDetailsProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product, quantity: number, packaging: string) => void;
  priceListId: PriceListId;
}

const ProductDetailsView: React.FC<ProductDetailsProps> = ({ product, onBack, onAddToCart, priceListId }) => {
  const [quantity, setQuantity] = useState(1);
  const [packaging, setPackaging] = useState(product.packagingTypes[0]);
  const [isAdded, setIsAdded] = useState(false);

  const currentPrice = product.prices[priceListId];

  const handleAdd = () => {
    onAddToCart(product, quantity, packaging);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-white animate-in slide-in-from-right-4 duration-300 relative">
      <div className="relative aspect-square">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        <button onClick={onBack} className="absolute top-4 left-4 bg-white/80 backdrop-blur-md p-2 rounded-full shadow-lg text-slate-800"><ChevronLeft size={24} /></button>
      </div>

      <div className="flex-1 bg-white -mt-8 rounded-t-[32px] p-6 shadow-[0_-10px_30px_rgba(0,0,0,0.05)]">
        <div className="flex justify-between items-start mb-2">
          <div>
            <div className="flex gap-1 items-center">
              <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">{product.mainCategory}</span>
              <span className="text-slate-300 text-[10px]">•</span>
              <span className="text-[10px] font-medium text-slate-500 uppercase tracking-widest">{product.subCategory}</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mt-1">{product.name}</h2>
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-slate-900">${currentPrice.toFixed(2)}</div>
            {priceListId !== 'STANDARD' && (
              <span className="text-[9px] font-black text-green-600 flex items-center justify-end gap-1">
                <Tag size={8} /> {priceListId} PRICE
              </span>
            )}
          </div>
        </div>

        <p className="text-slate-500 text-sm leading-relaxed mb-6">{product.description}</p>

        <div className="mb-6">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Packaging Type</h3>
          <div className="flex flex-wrap gap-2">
            {product.packagingTypes.map(type => (
              <button key={type} onClick={() => setPackaging(type)} className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all border ${packaging === type ? 'bg-slate-900 text-white border-slate-900 shadow-md' : 'bg-slate-50 text-slate-600 border-slate-200'}`}>{type}</button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl mb-24">
          <h3 className="text-sm font-bold text-slate-800">Order Quantity</h3>
          <div className="flex items-center gap-4 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-sm">
            <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="text-slate-400 p-1 hover:text-blue-600"><Minus size={18} /></button>
            <span className="font-bold text-slate-800 w-6 text-center">{quantity}</span>
            <button onClick={() => setQuantity(q => q + 1)} className="text-slate-400 p-1 hover:text-blue-600"><Plus size={18} /></button>
          </div>
        </div>
      </div>

      <div className="fixed bottom-24 left-4 right-4 max-w-md mx-auto z-10">
        <button onClick={handleAdd} disabled={isAdded} className={`w-full py-4 rounded-2xl font-bold text-white shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2 ${isAdded ? 'bg-green-500' : 'bg-blue-600 hover:bg-blue-700'}`}>
          {isAdded ? (<><CheckCircle size={20} />Added to Cart</>) : (<>Add to Cart — ${(currentPrice * quantity).toFixed(2)}</>)}
        </button>
      </div>
    </div>
  );
};

export default ProductDetailsView;
