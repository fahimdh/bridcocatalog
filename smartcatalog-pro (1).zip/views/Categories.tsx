
import React from 'react';
import { CATEGORY_STRUCTURE, PRODUCTS } from '../data';
import { MainCategory } from '../types';
import { ChevronRight } from 'lucide-react';

interface CategoriesViewProps {
  onCategoryClick: (main: MainCategory, sub: string) => void;
}

const CategoriesView: React.FC<CategoriesViewProps> = ({ onCategoryClick }) => {
  // Helper to find a representative image for a main category
  const getCategoryImage = (mainCat: MainCategory) => {
    const product = PRODUCTS.find(p => p.mainCategory === mainCat);
    return product ? product.image : 'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=400';
  };

  return (
    <div className="pb-12 animate-in slide-in-from-bottom-4 duration-300">
      <div className="p-6 bg-white border-b mb-2">
        <h2 className="text-2xl font-black text-slate-800 tracking-tight">Browse Departments</h2>
        <p className="text-sm text-slate-400 font-medium">Select a category to view specialized products</p>
      </div>

      <div className="p-4 space-y-8">
        {CATEGORY_STRUCTURE.map(cat => (
          <section key={cat.main} className="space-y-4">
            {/* Main Category Header with Image */}
            <div className="relative h-32 w-full rounded-3xl overflow-hidden shadow-lg group">
              <img 
                src={getCategoryImage(cat.main)} 
                alt={cat.main} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 via-slate-900/40 to-transparent flex flex-col justify-center px-6">
                <h3 className="text-xl font-black text-white tracking-widest uppercase italic">
                  {cat.main}
                </h3>
                <p className="text-blue-300 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">
                  {cat.subs.length} Specializations
                </p>
              </div>
            </div>

            {/* Sub Categories Grid */}
            <div className="grid grid-cols-2 gap-3">
              {cat.subs.map(sub => (
                <button
                  key={sub}
                  onClick={() => onCategoryClick(cat.main, sub)}
                  className="flex items-center justify-between p-4 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-blue-200 active:scale-95 transition-all text-left"
                >
                  <span className="text-[10px] font-black text-slate-600 uppercase leading-tight pr-2">
                    {sub}
                  </span>
                  <ChevronRight size={14} className="text-blue-500 shrink-0" />
                </button>
              ))}
            </div>
          </section>
        ))}
      </div>

      <div className="mt-8 mb-12 text-center px-10">
        <div className="h-px bg-slate-200 w-full mb-4"></div>
        <p className="text-[10px] text-slate-300 font-bold uppercase tracking-[0.3em]">SmartCatalog Digital Inventory</p>
      </div>
    </div>
  );
};

export default CategoriesView;
