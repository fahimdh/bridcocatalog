
import React from 'react';
import { ChevronLeft, UserCheck, Shield, ToggleLeft, ToggleRight, ListFilter } from 'lucide-react';
import { User, PriceListId } from '../types';

interface AdminViewProps {
  users: User[];
  onUpdateUser: (user: User) => void;
  onBack: () => void;
}

const AdminView: React.FC<AdminViewProps> = ({ users, onUpdateUser, onBack }) => {
  const handleToggleApproval = (user: User) => {
    onUpdateUser({ ...user, isApproved: !user.isApproved });
  };

  const handleChangePriceList = (user: User, priceListId: PriceListId) => {
    onUpdateUser({ ...user, priceListId });
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 animate-in slide-in-from-right-4 duration-300">
      <div className="bg-white p-4 border-b sticky top-0 flex items-center gap-3 z-10">
        <button onClick={onBack} className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500">
          <ChevronLeft size={24} />
        </button>
        <div>
          <h2 className="text-lg font-black text-slate-800">User Management</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Administrator Controls</p>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {users.map(user => (
          <div key={user.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full overflow-hidden border border-slate-200">
                <img src={user.avatar} className="w-full h-full object-cover" alt="" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-bold text-slate-800">{user.name}</h3>
                <p className="text-xs text-slate-400">{user.email}</p>
              </div>
              <div className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-tighter border ${user.isApproved ? 'bg-green-50 text-green-600 border-green-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
                {user.isApproved ? 'Approved' : 'Pending'}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-50">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                  <UserCheck size={10} /> Approval Status
                </label>
                <button 
                  onClick={() => handleToggleApproval(user)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-all ${user.isApproved ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'}`}
                >
                  {user.isApproved ? 'Revoke' : 'Approve'}
                  {user.isApproved ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                  <ListFilter size={10} /> Price List
                </label>
                <select 
                  value={user.priceListId}
                  onChange={(e) => handleChangePriceList(user, e.target.value as PriceListId)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="STANDARD">Standard</option>
                  <option value="WHOLESALE">Wholesale</option>
                  <option value="VIP">VIP Tier</option>
                </select>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="p-8 text-center">
        <Shield size={32} className="mx-auto text-slate-200 mb-2" />
        <p className="text-xs text-slate-300 font-medium">Changes here apply immediately and are saved to local persistence.</p>
      </div>
    </div>
  );
};

export default AdminView;
