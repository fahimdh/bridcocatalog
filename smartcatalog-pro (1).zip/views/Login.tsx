
import React, { useState } from 'react';
import { LogIn, Mail, Lock, ShieldCheck, UserPlus, ArrowLeft } from 'lucide-react';

interface LoginViewProps {
  onLogin: (email: string) => void;
  onRegister: (name: string, email: string) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin, onRegister }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegistering) {
      onRegister(name, email);
    } else {
      onLogin(email);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 max-w-md mx-auto">
      <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center text-white mb-8 shadow-2xl shadow-blue-200 animate-in zoom-in duration-500">
        <ShieldCheck size={40} />
      </div>
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">
          {isRegistering ? 'Create Account' : 'Welcome Back'}
        </h1>
        <p className="text-slate-500 mt-2 font-medium">
          {isRegistering 
            ? 'Fill in your details to request access' 
            : 'Please sign in to view products and prices'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="w-full space-y-4">
        {isRegistering && (
          <div className="relative animate-in slide-in-from-top-2">
            <UserPlus className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full Business Name"
              className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
              required
            />
          </div>
        )}

        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email Address"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
            required
          />
        </div>
        
        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
            required
          />
        </div>

        <button 
          type="submit"
          className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 mt-4"
        >
          {isRegistering ? <UserPlus size={20} /> : <LogIn size={20} />}
          {isRegistering ? 'Submit Request' : 'Secure Sign In'}
        </button>
      </form>

      <div className="mt-8 text-center space-y-4 w-full">
        {!isRegistering && (
          <button className="text-sm font-bold text-blue-600 hover:underline">Forgot your password?</button>
        )}
        <div className="h-px bg-slate-200 w-full"></div>
        <p className="text-sm text-slate-500 font-medium">
          {isRegistering ? 'Already have an account?' : 'New partner?'}
          <button 
            onClick={() => setIsRegistering(!isRegistering)}
            className="text-blue-600 font-bold ml-2 hover:underline flex items-center gap-1 mx-auto mt-2"
          >
            {isRegistering ? (
              <><ArrowLeft size={16} /> Back to Login</>
            ) : (
              'Request Access Here'
            )}
          </button>
        </p>
      </div>

      {!isRegistering && (
        <div className="mt-12 p-4 bg-blue-50 rounded-xl border border-blue-100 text-[10px] text-blue-700 font-bold text-center uppercase tracking-widest">
          DEMO: Try 'admin@demo.com' or 'vip@wholesale.com'
        </div>
      )}
    </div>
  );
};

export default LoginView;
