
import React, { useState, useRef, useEffect } from 'react';
import { Search as SearchIcon, Camera, X, QrCode, Plus, Minus, ShoppingCart, Loader2 } from 'lucide-react';
import { Product, CartItem, PriceListId } from '../types';
import { PRODUCTS } from '../data';

interface SearchProps {
  onProductClick: (p: Product) => void;
  onQuickAdd: (p: Product) => void;
  onUpdateQuantity: (p: Product, delta: number) => void;
  cart: CartItem[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  priceListId: PriceListId;
}

const SearchView: React.FC<SearchProps> = ({ 
  onProductClick, onQuickAdd, onUpdateQuantity, cart, 
  searchQuery, setSearchQuery, priceListId 
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatus, setScanStatus] = useState<'idle' | 'searching' | 'found'>('idle');
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const filteredProducts = PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.mainCategory.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.subCategory.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    let currentStream: MediaStream | null = null;
    let scanTimeout: number;

    const startCamera = async () => {
      if (isScanning && videoRef.current) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
          });
          currentStream = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(e => console.warn("Video playback was interrupted", e));
            
            // AUTOMATED SMART SCAN SIMULATION
            setScanStatus('searching');
            scanTimeout = window.setTimeout(() => {
              const randomProduct = PRODUCTS[Math.floor(Math.random() * PRODUCTS.length)];
              setScanStatus('found');
              setTimeout(() => {
                setSearchQuery(randomProduct.name);
                stopScan();
              }, 800);
            }, 2500);
          }
        } catch (err) {
          console.error("Camera access error:", err);
          setIsScanning(false);
          alert("Camera access denied. Please allow camera permissions.");
        }
      }
    };

    if (isScanning) {
      startCamera();
      return () => {
        if (currentStream) currentStream.getTracks().forEach(track => track.stop());
        if (scanTimeout) clearTimeout(scanTimeout);
      };
    }
  }, [isScanning]);

  const stopScan = () => {
    setIsScanning(false);
    setScanStatus('idle');
  };

  const getItemQuantity = (productId: string) => {
    return cart.filter(item => item.id === productId).reduce((acc, item) => acc + item.quantity, 0);
  };

  return (
    <div className="p-4 space-y-4">
      <div className="relative">
        <input 
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by name or category..."
          className="w-full bg-white border border-slate-200 rounded-2xl py-3.5 pl-12 pr-12 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
        />
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
        <button 
          onClick={() => setIsScanning(true)}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-600 p-1.5 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
        >
          <Camera size={20} />
        </button>
      </div>

      {isScanning && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden border-4 border-blue-500 shadow-2xl bg-slate-900">
            <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
            
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className={`w-64 h-48 border-2 border-dashed rounded-xl relative transition-all duration-300 ${scanStatus === 'found' ? 'border-green-400 scale-110' : 'border-white/50'}`}>
                {scanStatus === 'searching' && (
                  <div className="absolute inset-0 flex items-center overflow-hidden">
                    <div className="w-full h-1 bg-blue-500/80 shadow-[0_0_15px_blue] animate-[bounce_2s_infinite]"></div>
                  </div>
                )}
                {scanStatus === 'found' && (
                  <div className="absolute inset-0 bg-green-500/20 flex items-center justify-center">
                    <div className="bg-white text-green-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">Product Detected</div>
                  </div>
                )}
              </div>
            </div>

            <div className="absolute top-4 right-4">
               <button onClick={stopScan} className="bg-white/20 backdrop-blur-md p-2 rounded-full text-white">
                 <X size={24} />
               </button>
            </div>

            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-full px-8 text-center">
              <div className="bg-black/60 backdrop-blur-md py-3 px-4 rounded-2xl flex items-center justify-center gap-3">
                {scanStatus === 'searching' ? (
                  <>
                    <Loader2 size={16} className="text-blue-400 animate-spin" />
                    <span className="text-white text-xs font-bold uppercase tracking-widest">Smart-Scanning Active...</span>
                  </>
                ) : (
                  <span className="text-green-400 text-xs font-bold uppercase tracking-widest">Analyzing Barcode...</span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {filteredProducts.length > 0 ? (
          filteredProducts.map(product => {
            const quantity = getItemQuantity(product.id);
            const isInCart = quantity > 0;
            const isExpanded = expandedProductId === product.id && isInCart;
            const currentPrice = product.prices[priceListId];

            return (
              <div 
                key={product.id}
                onClick={() => onProductClick(product)}
                className="flex items-center gap-4 bg-white p-3 rounded-2xl shadow-sm border border-slate-100 active:bg-slate-50 transition-colors cursor-pointer"
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-100 shrink-0 relative">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-slate-800 text-sm truncate">{product.name}</h4>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wide truncate">{product.subCategory}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <p className="text-blue-600 font-black text-sm">${currentPrice.toFixed(2)}</p>
                    {priceListId !== 'STANDARD' && <span className="text-[8px] font-black text-green-600">({priceListId})</span>}
                  </div>
                </div>
                
                <div className="flex items-center min-w-[44px] justify-end" onClick={(e) => e.stopPropagation()}>
                  {!isInCart ? (
                    <button 
                      onClick={() => { onQuickAdd(product); setExpandedProductId(product.id); }}
                      className="bg-slate-100 text-slate-500 p-1.5 rounded-xl border border-slate-200"
                    >
                      <Plus size={16} />
                    </button>
                  ) : isExpanded ? (
                    <div className="flex items-center bg-blue-600 rounded-xl shadow-md overflow-hidden animate-in slide-in-from-right-2">
                      <button 
                        onClick={() => { onUpdateQuantity(product, -1); if (quantity === 1) setExpandedProductId(null); }}
                        className="p-1.5 text-white hover:bg-blue-700 active:scale-75"
                      >
                        <Minus size={14} strokeWidth={3} />
                      </button>
                      <span className="text-xs font-black text-white px-1 min-w-[20px] text-center">{quantity}</span>
                      <button 
                        onClick={() => onUpdateQuantity(product, 1)}
                        className="p-1.5 text-white hover:bg-blue-700 active:scale-75"
                      >
                        <Plus size={14} strokeWidth={3} />
                      </button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setExpandedProductId(product.id)}
                      className="bg-blue-600 text-white p-2 rounded-xl shadow-md relative"
                    >
                      <ShoppingCart size={16} strokeWidth={2.5} />
                      <span className="absolute -top-1.5 -right-1 bg-white text-blue-600 text-[9px] font-black w-3.5 h-3.5 flex items-center justify-center rounded-full border border-blue-600 shadow-sm">{quantity}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-20 text-slate-400">
            <SearchIcon size={24} className="mx-auto mb-4 opacity-20" />
            <p className="text-sm font-bold">No results found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchView;
