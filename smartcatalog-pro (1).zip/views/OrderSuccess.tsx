
import React from 'react';
import { CheckCircle, ArrowRight, Package, Calendar, MapPin } from 'lucide-react';
import { CartItem } from '../types';

interface OrderSuccessViewProps {
  cart: CartItem[];
  onContinue: () => void;
}

const OrderSuccessView: React.FC<OrderSuccessViewProps> = ({ cart, onContinue }) => {
  const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0) + 12.00;
  const orderNumber = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;

  return (
    <div className="flex flex-col h-full bg-white animate-in zoom-in-95 duration-500 p-6 overflow-y-auto">
      <div className="flex flex-col items-center justify-center pt-12 pb-8 text-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-6 shadow-xl shadow-green-100">
          <CheckCircle size={56} className="animate-in slide-in-from-bottom-2" />
        </div>
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Order Confirmed!</h2>
        <p className="text-slate-400 font-medium mt-2">Thank you for your business. Your request is being processed.</p>
      </div>

      <div className="bg-slate-50 rounded-[32px] p-6 space-y-6 border border-slate-100">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Order Number</p>
            <p className="text-sm font-bold text-slate-800">{orderNumber}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Estimated Delivery</p>
            <p className="text-sm font-bold text-slate-800">2-3 Business Days</p>
          </div>
        </div>

        <div className="h-px bg-slate-200 w-full"></div>

        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <MapPin size={18} className="text-blue-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-slate-800">Default Shipping Address</p>
              <p className="text-[11px] text-slate-500">123 Business Lane, Suite 400, Industrial Park</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Calendar size={18} className="text-blue-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-slate-800">Order Placed On</p>
              <p className="text-[11px] text-slate-500">{new Date().toLocaleDateString('en-US', { dateStyle: 'long' })}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Package size={12} /> Items Summary
          </p>
          <div className="space-y-2">
            {cart.slice(0, 3).map((item, i) => (
              <div key={i} className="flex justify-between text-xs">
                <span className="text-slate-600 truncate mr-4">{item.quantity}x {item.name}</span>
                <span className="font-bold text-slate-800">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            {cart.length > 3 && (
              <p className="text-[10px] text-slate-400 italic">...and {cart.length - 3} more items</p>
            )}
          </div>
          <div className="h-px bg-slate-50 my-3"></div>
          <div className="flex justify-between items-center">
            <span className="text-sm font-bold text-slate-800">Total Charged</span>
            <span className="text-lg font-black text-blue-600">${total.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="mt-8 pb-12">
        <button 
          onClick={onContinue}
          className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3"
        >
          Continue Shopping
          <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
};

export default OrderSuccessView;
