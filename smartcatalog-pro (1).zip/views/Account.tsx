
import React from 'react';
import { User as UserIcon, Settings, CreditCard, MapPin, Bell, Shield, LogOut, ChevronRight, Tag, Settings2 } from 'lucide-react';
import { User } from '../types';

interface AccountViewProps {
  user: User;
  onLogout: () => void;
  onAdminClick: () => void;
}

const AccountView: React.FC<AccountViewProps> = ({ user, onLogout, onAdminClick }) => {
  const menuItems = [
    { icon: <UserIcon size={20} />, label: 'Personal Information', color: 'text-blue-500' },
    { icon: <CreditCard size={20} />, label: 'Payment Methods', color: 'text-purple-500' },
    { icon: <MapPin size={20} />, label: 'Delivery Addresses', color: 'text-orange-500' },
    { icon: <Bell size={20} />, label: 'Notifications', color: 'text-green-500' },
    { icon: <Shield size={20} />, label: 'Security & Privacy', color: 'text-indigo-500' },
  ];

  return (
    <div className="p-4 space-y-6 animate-in slide-in-from-bottom-4">
      {/* Profile Header */}
      <div className="bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 flex items-center gap-4">
        <div className="relative">
          <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-blue-50">
            <img src={user.avatar} alt="User Profile" className="w-full h-full object-cover" />
          </div>
          <div className={`absolute bottom-0 right-0 w-6 h-6 rounded-full border-2 border-white ${user.isApproved ? 'bg-green-500' : 'bg-amber-500'}`}></div>
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800">{user.name}</h2>
          <p className="text-xs text-slate-500 font-medium">{user.email}</p>
          <div className="mt-2 flex flex-wrap gap-1">
            <span className={`inline-block px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest border ${user.isApproved ? 'bg-blue-50 text-blue-600 border-blue-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
              {user.isApproved ? 'Verified' : 'Pending'}
            </span>
            <span className="inline-block px-2 py-0.5 bg-green-50 text-green-600 text-[8px] font-black rounded-full uppercase tracking-widest border border-green-100 flex items-center gap-1">
              <Tag size={8} /> {user.priceListId}
            </span>
          </div>
        </div>
      </div>

      {/* Admin Panel (Demo Purpose) */}
      <div className="bg-slate-900 p-4 rounded-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3 text-white">
            <Settings2 size={24} className="text-blue-400" />
            <div>
              <h3 className="text-sm font-bold">Admin Controls</h3>
              <p className="text-[10px] text-slate-400">Manage Users & Pricelists</p>
            </div>
          </div>
        </div>
        <button 
          onClick={onAdminClick}
          className="w-full bg-white/10 hover:bg-white/20 text-white py-3 rounded-2xl text-xs font-bold transition-all border border-white/10 flex items-center justify-center gap-2"
        >
          Open Management Dashboard
          <ChevronRight size={16} />
        </button>
      </div>

      {/* Menu Sections */}
      <div className="space-y-2">
        {menuItems.map((item, idx) => (
          <button 
            key={idx}
            className="w-full bg-white p-4 rounded-2xl flex items-center justify-between shadow-sm border border-slate-50 hover:bg-slate-50 transition-colors group"
          >
            <div className="flex items-center gap-4">
              <div className={`p-2 rounded-xl bg-slate-50 ${item.color} group-hover:scale-110 transition-transform`}>
                {item.icon}
              </div>
              <span className="text-sm font-semibold text-slate-700">{item.label}</span>
            </div>
            <ChevronRight size={18} className="text-slate-300" />
          </button>
        ))}
      </div>

      {/* Logout */}
      <button 
        onClick={onLogout}
        className="w-full bg-red-50 text-red-600 p-4 rounded-2xl flex items-center justify-center gap-2 font-bold hover:bg-red-100 transition-colors mt-2"
      >
        <LogOut size={20} />
        Sign Out Securely
      </button>

      <div className="text-center py-4">
        <p className="text-[10px] text-slate-300 font-black uppercase tracking-widest">SmartCatalog Pro Enterprise v2.1</p>
      </div>
    </div>
  );
};

export default AccountView;
