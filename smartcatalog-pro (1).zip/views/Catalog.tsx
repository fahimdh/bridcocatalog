
import React, { useState } from 'react';
import { Plus, Minus, ShoppingCart } from 'lucide-react';
import { Product, MainCategory, CartItem, PriceListId } from '../types';
import { PRODUCTS, CATEGORY_STRUCTURE } from '../data';

interface CatalogProps {
  onProductClick: (p: Product) => void;
  onQuickAdd: (p: Product) => void;
  onUpdateQuantity: (p: Product, delta: number) => void;
  cart: CartItem[];
  selectedMainCategory: MainCategory | 'All';
  setSelectedMainCategory: (c: MainCategory | 'All') => void;
  selectedSubCategory: string | 'All';
  setSelectedSubCategory: (s: string | 'All') => void;
  priceListId: PriceListId;
}

const CatalogView: React.FC<CatalogProps> = ({ 
  onProductClick, onQuickAdd, onUpdateQuantity, cart, 
  selectedMainCategory, setSelectedMainCategory,
  selectedSubCategory, setSelectedSubCategory,
  priceListId
}) => {
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);

  const filteredProducts = PRODUCTS.filter(p => {
    const mainMatch = selectedMainCategory === 'All' || p.mainCategory === selectedMainCategory;
    const subMatch = selectedSubCategory === 'All' || p.subCategory === selectedSubCategory;
    return mainMatch && subMatch;
  });

  const availableSubs = selectedMainCategory === 'All' 
    ? [] 
    : CATEGORY_STRUCTURE.find(c => c.main === selectedMainCategory)?.subs || [];

  const getItemQuantity = (productId: string) => {
    return cart.filter(item => item.id === productId).reduce((acc, item) => acc + item.quantity, 0);
  };

  return (
    <div className="p-3 animate-in fade-in duration-300">
      {/* Main Category Filter */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-2 pb-1 -mx-1 px-1">
        <button
          onClick={() => { setSelectedMainCategory('All'); setSelectedSubCategory('All'); }}
          className={`px-3 py-1.5 rounded-full text-[10px] font-bold whitespace-nowrap border transition-all ${
            selectedMainCategory === 'All' ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-white text-slate-600 border-slate-200'
          }`}
        >
          ALL ITEMS
        </button>
        {CATEGORY_STRUCTURE.map(cat => (
          <button
            key={cat.main}
            onClick={() => { setSelectedMainCategory(cat.main); setSelectedSubCategory('All'); }}
            className={`px-3 py-1.5 rounded-full text-[10px] font-bold whitespace-nowrap border transition-all ${
              selectedMainCategory === cat.main ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-white text-slate-600 border-slate-200'
            }`}
          >
            {cat.main}
          </button>
        ))}
      </div>

      {/* Sub Category Filter */}
      {selectedMainCategory !== 'All' && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar mb-4 pb-2 -mx-1 px-1 border-t pt-2">
          <button
            onClick={() => setSelectedSubCategory('All')}
            className={`px-2.5 py-1 rounded-lg text-[9px] font-medium whitespace-nowrap border transition-all ${
              selectedSubCategory === 'All' ? 'bg-slate-800 text-white border-slate-800 shadow-sm' : 'bg-slate-50 text-slate-500 border-slate-100'
            }`}
          >
            ALL {selectedMainCategory}
          </button>
          {availableSubs.map(sub => (
            <button
              key={sub}
              onClick={() => setSelectedSubCategory(sub)}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-medium whitespace-nowrap border transition-all ${
                selectedSubCategory === sub ? 'bg-slate-800 text-white border-slate-800 shadow-sm' : 'bg-slate-50 text-slate-500 border-slate-100'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      )}

      {/* Product Grid */}
      <div className="grid grid-cols-3 gap-x-2 gap-y-6">
        {filteredProducts.map(product => {
          const quantity = getItemQuantity(product.id);
          const isInCart = quantity > 0;
          const isExpanded = expandedProductId === product.id && isInCart;
          const currentPrice = product.prices[priceListId];

          return (
            <div key={product.id} onClick={() => onProductClick(product)} className="flex flex-col group cursor-pointer active:scale-95 transition-transform">
              <div className="aspect-square rounded-2xl overflow-hidden bg-white shadow-sm border border-slate-100 relative mb-2">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                <div className="absolute bottom-1 right-1 z-20" onClick={(e) => e.stopPropagation()}>
                  {!isInCart ? (
                    <button onClick={() => { onQuickAdd(product); setExpandedProductId(product.id); }} className="bg-white text-slate-800 p-1 rounded-xl shadow-md border border-slate-100">
                      <Plus size={14} strokeWidth={2.5} />
                    </button>
                  ) : isExpanded ? (
                    <div className="flex items-center bg-blue-600 rounded-xl shadow-xl border border-white/20 animate-in zoom-in-95 duration-200 overflow-hidden">
                      <button onClick={() => { onUpdateQuantity(product, -1); if (quantity === 1) setExpandedProductId(null); }} className="p-1 text-white hover:bg-blue-700 active:scale-75"><Minus size={12} strokeWidth={3} /></button>
                      <span className="text-[10px] font-black text-white min-w-[14px] text-center px-0.5">{quantity}</span>
                      <button onClick={() => onUpdateQuantity(product, 1)} className="p-1 text-white hover:bg-blue-700 active:scale-75"><Plus size={12} strokeWidth={3} /></button>
                    </div>
                  ) : (
                    <button onClick={() => setExpandedProductId(product.id)} className="bg-blue-600 text-white p-1.5 rounded-xl shadow-lg relative">
                      <ShoppingCart size={14} strokeWidth={2.5} />
                      <span className="absolute -top-1.5 -right-1.5 bg-white text-blue-600 text-[8px] font-black w-3.5 h-3.5 flex items-center justify-center rounded-full border border-blue-600 shadow-sm">{quantity}</span>
                    </button>
                  )}
                </div>
              </div>
              <h3 className="text-[10px] font-bold text-slate-800 leading-tight line-clamp-2 px-0.5 min-h-[2.4em]">{product.name}</h3>
              <p className="text-[8px] text-slate-400 px-0.5 truncate uppercase tracking-tighter">{product.subCategory}</p>
              <div className="flex items-center gap-1 mt-0.5">
                <p className="text-[11px] font-black text-slate-900 px-0.5">${currentPrice.toFixed(2)}</p>
                {priceListId !== 'STANDARD' && (
                  <span className="text-[7px] bg-green-50 text-green-600 px-1 rounded-sm font-black border border-green-100">
                    {priceListId}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
      
      {filteredProducts.length === 0 && (
        <div className="text-center py-20 text-slate-400">
          <p className="text-sm">No products found.</p>
          <p className="text-xs">Try a different subcategory.</p>
        </div>
      )}
    </div>
  );
};

export default CatalogView;
